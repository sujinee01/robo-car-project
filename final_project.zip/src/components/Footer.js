/*
 페이지 하단 푸터 부분 구현하는 JS 파일입니다.
*/

const Footer = () => {
  return 
}

export default Footer;